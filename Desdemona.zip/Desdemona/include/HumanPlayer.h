#ifndef HUMANPLAYER_H
#define HUMANPLAYER_H

#endif /* #ifndef HUMANPLAYER_H */
